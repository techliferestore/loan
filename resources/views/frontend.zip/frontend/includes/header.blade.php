<!--wrapper start-->
<div class="wrapper">

    <!--== Start Preloader Content ==-->
    <div class="preloader-wrap">
      <div class="preloader">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
    <!--== End Preloader Content ==-->
  
    <!--== Start Header Wrapper ==-->
    <header class="header-wrapper">
      <div class="header-top-area">
        <div class="header-top-align">
          <div class="header-top-align-left">
            <div class="header-logo-area">
              <a href="index.html">
                <img class="logo-main" src="assets/img/logo.png" alt="Logo" />
                <img class="logo-light" src="assets/img/logo-light.png" alt="Logo" />
              </a>
            </div>
          </div>
          <div class="header-top-align-right">
            <div class="header-info-items">
              <div class="info-items">
                <div class="inner-content">
                  <div class="icon">
                    <img src="assets/img/icons/time1.png" alt="Image-HasTech">
                  </div>
                  <div class="content">
                    <p>8 am to 6 pm (Mon - Fri)<br>10 am to 8 pm (Sat - Sun)</p>
                  </div>
                </div>
              </div>
              <div class="info-items">
                <div class="inner-content">
                  <div class="icon">
                    <img src="assets/img/icons/map.png" alt="Image-HasTech">
                  </div>
                  <div class="content">
                    <p>258C, Saintpatrick, Main Street <br>Notrth Town, New York</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="header-appointment-button">
              <a class="appointment-btn" href="contact.html">Appointment</a>
            </div>
          </div>
        </div>
      </div>
      <div class="responsive-header-appointment-button">
        <a class="appointment-btn" href="contact.html">Appointment</a>
      </div>
      <div class="header-area sticky-header header-default">
        <div class="container">
          <div class="row no-gutter align-items-center position-relative">
            <div class="col-12">
              <div class="header-align">
                <div class="header-align-left">
                  <button class="btn-menu" type="button"><i class="fa fa-align-left"></i></button>
                  <div class="header-navigation-area">
                    <ul class="main-menu nav">
                      <li><a href="index.html"><span>Home</span></a></li>
                      <li class="has-submenu"><a href="#/"><span>Services</span></a>                      
                      </li>
                      <li ><a href="#/"><span>Dentist</span></a>
                      
                      </li>
                      <li >
                        <a href="#/"><span>About Us</span></a>
                      
                      </li>
                      <li><a href="#/"><span>Blog</span></a>
                         </li>
                      <li><a href="contact.html"><span>Contact</span></a></li>
                    </ul>
                  </div>
                </div>
                <div class="header-align-right">
                    @guest

                  <div class="header-action-area">
                    <a  href="{{ route('login') }}" >Login</a>
                    <span>/</span>
                
                    <a href="{{ route('register') }}">Register</a>
                  </div>
              
                 
                  @endguest


                  @auth
                  <ul class="main-menu nav">
                  <li class="has-submenu">
                    <a href="#" >
                        <span style="color: #fff;
                        font-size: 22px;
                        font-family: 'Shippori Mincho', serif;
                        font-weight: 600;
                        height: 80px;
                        letter-spacing: 0px;
                        position: relative;
                        margin: 0 18px;
                        padding: 0 20px;
                        text-transform: capitalize;">{{ Auth::user()->name }} </span> 
                    </a>
                    <ul class="submenu-nav">                   
                   
                    @can('view_backend')
                      <a href='{{ route("backend.dashboard") }}' >
                      {{__('Admin Dashboard')}}
                      </a>
                      @endif
                    
                      <li> 
                        <a href="{{ route('frontend.users.profile', encode_id(auth()->user()->id)) }}" >
                                 {{__('Profile')}}
                                 </a>
                               
                    <li> 
             <a href="{{ route('frontend.users.profileEdit', encode_id(auth()->user()->id)) }}" >
                      {{__('Settings')}}
                      </a>
                    
                    </li>
                    
                    <li> 
                         <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" >
                          {{__('Logout')}}
                      </a>
                    </li>
                

                      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                          {{ csrf_field() }}
                      </form>
                    </ul>
                </li>
                  </ul>
                  @endauth
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!--== End Header Wrapper ==-->
    
 