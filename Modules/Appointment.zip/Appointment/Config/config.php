<?php

return [
    'name' => 'Appointment'
];
